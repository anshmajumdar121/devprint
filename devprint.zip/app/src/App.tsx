import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

import Navigation from './sections/Navigation';
import HeroSection from './sections/HeroSection';
import IdentitySection from './sections/IdentitySection';
import ProfileCardSection from './sections/ProfileCardSection';
import ProofMetricsSection from './sections/ProofMetricsSection';
import StackDetectionSection from './sections/StackDetectionSection';
import HeatmapSection from './sections/HeatmapSection';
import ImpactScoreSection from './sections/ImpactScoreSection';
import NetworkGraphSection from './sections/NetworkGraphSection';
import HowItWorksSection from './sections/HowItWorksSection';
import PricingSection from './sections/PricingSection';
import FinalCTASection from './sections/FinalCTASection';
import FooterSection from './sections/FooterSection';

import './App.css';

gsap.registerPlugin(ScrollTrigger);

function App() {
  const mainRef = useRef<HTMLElement>(null);
  const snapTriggerRef = useRef<ScrollTrigger | null>(null);

  useEffect(() => {
    // Wait for all section ScrollTriggers to be created
    const timer = setTimeout(() => {
      const pinned = ScrollTrigger.getAll()
        .filter((st) => st.vars.pin)
        .sort((a, b) => a.start - b.start);

      const maxScroll = ScrollTrigger.maxScroll(window);

      if (!maxScroll || pinned.length === 0) return;

      // Build pinned ranges with settle centers
      const pinnedRanges = pinned.map((st) => {
        const start = st.start / maxScroll;
        const end = (st.end ?? st.start) / maxScroll;
        const settleRatio = 0.5; // Default settle ratio
        const center = start + (end - start) * settleRatio;
        return { start, end, center };
      });

      // Create global snap
      snapTriggerRef.current = ScrollTrigger.create({
        snap: {
          snapTo: (value: number) => {
            // Check if within any pinned range (with buffer)
            const inPinned = pinnedRanges.some(
              (r) => value >= r.start - 0.02 && value <= r.end + 0.02
            );

            // If not in pinned section, allow free scroll
            if (!inPinned) return value;

            // Find nearest pinned center
            const target = pinnedRanges.reduce(
              (closest, r) =>
                Math.abs(r.center - value) < Math.abs(closest - value)
                  ? r.center
                  : closest,
              pinnedRanges[0]?.center ?? 0
            );

            return target;
          },
          duration: { min: 0.15, max: 0.35 },
          delay: 0,
          ease: 'power2.out',
        },
      });
    }, 500);

    return () => {
      clearTimeout(timer);
      if (snapTriggerRef.current) {
        snapTriggerRef.current.kill();
      }
    };
  }, []);

  // Cleanup all ScrollTriggers on unmount
  useEffect(() => {
    return () => {
      ScrollTrigger.getAll().forEach((st) => st.kill());
    };
  }, []);

  return (
    <>
      {/* Grain Overlay */}
      <div className="grain-overlay" />

      {/* Navigation */}
      <Navigation />

      {/* Main Content */}
      <main ref={mainRef} className="relative">
        {/* Section 1: Hero - pin: true */}
        <HeroSection />

        {/* Section 2: Identity - pin: true */}
        <IdentitySection />

        {/* Section 3: Profile Card - pin: true */}
        <ProfileCardSection />

        {/* Section 4: Proof Metrics - pin: false */}
        <ProofMetricsSection />

        {/* Section 5: Stack Detection - pin: true */}
        <StackDetectionSection />

        {/* Section 6: Heatmap - pin: true */}
        <HeatmapSection />

        {/* Section 7: Impact Score - pin: true */}
        <ImpactScoreSection />

        {/* Section 8: Network Graph - pin: true */}
        <NetworkGraphSection />

        {/* Section 9: How It Works - pin: false */}
        <HowItWorksSection />

        {/* Section 10: Pricing - pin: false */}
        <PricingSection />

        {/* Section 11: Final CTA - pin: true */}
        <FinalCTASection />

        {/* Section 12: Footer - pin: false */}
        <FooterSection />
      </main>
    </>
  );
}

export default App;
