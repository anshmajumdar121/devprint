import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Copy, Check } from 'lucide-react';
import { useState } from 'react';

gsap.registerPlugin(ScrollTrigger);

export default function IdentitySection() {
  const sectionRef = useRef<HTMLElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const bodyRef = useRef<HTMLDivElement>(null);
  const linkRef = useRef<HTMLDivElement>(null);
  const portraitRef = useRef<HTMLDivElement>(null);
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText('devprint.dev/u/yourname');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const headline = headlineRef.current;
    const body = bodyRef.current;
    const link = linkRef.current;
    const portrait = portraitRef.current;

    if (!section || !headline || !body || !link || !portrait) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // ENTRANCE (0%-30%)
      scrollTl.fromTo(
        headline,
        { x: '-50vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0
      );

      scrollTl.fromTo(
        body,
        { y: '18vh', opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.05
      );

      scrollTl.fromTo(
        link,
        { x: '-30vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0.1
      );

      scrollTl.fromTo(
        portrait,
        { x: '60vw', opacity: 0, scale: 0.96 },
        { x: 0, opacity: 1, scale: 1, ease: 'none' },
        0
      );

      // SETTLE (30%-70%): Micro parallax on portrait
      scrollTl.fromTo(
        portrait,
        { y: 0 },
        { y: '-2vh', ease: 'none' },
        0.3
      );

      // EXIT (70%-100%)
      scrollTl.fromTo(
        headline,
        { x: 0, opacity: 1 },
        { x: '-18vw', opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(
        body,
        { y: 0, opacity: 1 },
        { y: '-10vh', opacity: 0, ease: 'power2.in' },
        0.72
      );

      scrollTl.fromTo(
        link,
        { x: 0, opacity: 1 },
        { x: '-20vw', opacity: 0, ease: 'power2.in' },
        0.74
      );

      scrollTl.fromTo(
        portrait,
        { x: 0, opacity: 1, scale: 1 },
        { x: '20vw', opacity: 0, scale: 0.98, ease: 'power2.in' },
        0.7
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="section-pinned z-20 flex items-center"
      style={{ background: '#07070B' }}
    >
      <div className="w-full px-6 lg:px-[6vw] flex flex-col lg:flex-row items-center justify-between gap-12">
        {/* Left Content */}
        <div className="flex-1 max-w-xl">
          {/* Headline */}
          <div ref={headlineRef} className="mb-8">
            <h2 className="headline-lg text-devprint-text" style={{ fontSize: 'clamp(36px, 4.6vw, 72px)' }}>
              <span className="block">ONE LINK</span>
              <span className="block text-devprint-accent">THAT SAYS IT ALL</span>
            </h2>
          </div>

          {/* Body */}
          <div ref={bodyRef} className="mb-8">
            <p className="text-devprint-text-secondary text-lg leading-relaxed">
              Developers are more than a résumé. DevPrint aggregates your GitHub, articles, 
              launches, and open-source impact into a unified identity.
            </p>
          </div>

          {/* Link Pill */}
          <div ref={linkRef}>
            <button
              onClick={handleCopy}
              className="link-pill group hover:border-devprint-accent/50 transition-colors"
            >
              <span>devprint.dev/u/yourname</span>
              {copied ? (
                <Check className="w-4 h-4 text-devprint-accent" />
              ) : (
                <Copy className="w-4 h-4 opacity-50 group-hover:opacity-100 transition-opacity" />
              )}
            </button>
          </div>
        </div>

        {/* Right Portrait */}
        <div
          ref={portraitRef}
          className="w-full lg:w-[34vw] lg:h-[64vh] rounded-2xl overflow-hidden card-glass"
        >
          <img
            src="/portrait_identity.jpg"
            alt="Developer portrait"
            className="w-full h-full object-cover"
          />
        </div>
      </div>
    </section>
  );
}
