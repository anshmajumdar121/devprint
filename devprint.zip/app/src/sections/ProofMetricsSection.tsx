import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export default function ProofMetricsSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const paragraphRef = useRef<HTMLParagraphElement>(null);
  const statsRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const headline = headlineRef.current;
    const paragraph = paragraphRef.current;
    const stats = statsRef.current;

    if (!section || !headline || !paragraph || !stats) return;

    const ctx = gsap.context(() => {
      // Headline animation
      gsap.fromTo(
        headline,
        { y: 30, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.6,
          scrollTrigger: {
            trigger: headline,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Paragraph animation
      gsap.fromTo(
        paragraph,
        { y: 20, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.5,
          delay: 0.1,
          scrollTrigger: {
            trigger: paragraph,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Stats animation with stagger
      const statItems = stats.querySelectorAll('.stat-item');
      gsap.fromTo(
        statItems,
        { y: 40, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          stagger: 0.12,
          duration: 0.6,
          scrollTrigger: {
            trigger: stats,
            start: 'top 75%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  const stats = [
    { value: '120K+', label: 'Profiles indexed', caption: 'and growing daily' },
    { value: '8.4M', label: 'Repos analyzed', caption: 'across GitHub & GitLab' },
    { value: '99.9%', label: 'Uptime', caption: 'fast, reliable, always on' },
  ];

  return (
    <section
      ref={sectionRef}
      className="section-flowing z-40 py-20 lg:py-32"
      style={{ background: '#07070B' }}
    >
      <div className="px-6 lg:px-[6vw]">
        {/* Header */}
        <div className="flex flex-col lg:flex-row lg:justify-between lg:items-start gap-6 mb-16 lg:mb-24">
          <div ref={headlineRef}>
            <h2 className="headline-lg text-devprint-text" style={{ fontSize: 'clamp(36px, 4.6vw, 72px)' }}>
              <span className="block">BUILT FOR DEVELOPERS</span>
              <span className="block text-devprint-accent">WHO SHIP</span>
            </h2>
          </div>
          <p
            ref={paragraphRef}
            className="text-devprint-text-secondary text-lg max-w-md lg:text-right"
          >
            From indie makers to platform engineers—DevPrint captures the work that matters.
          </p>
        </div>

        {/* Stats */}
        <div
          ref={statsRef}
          className="grid grid-cols-1 md:grid-cols-3 gap-8 lg:gap-12"
        >
          {stats.map((stat, i) => (
            <div key={i} className="stat-item">
              <div className="stat-number mb-2">{stat.value}</div>
              <div className="font-display font-semibold text-devprint-text text-lg mb-1">
                {stat.label}
              </div>
              <div className="text-devprint-text-secondary text-sm">{stat.caption}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
