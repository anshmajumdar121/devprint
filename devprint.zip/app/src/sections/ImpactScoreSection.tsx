import { useRef, useLayoutEffect, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Button } from '@/components/ui/button';
import { TrendingUp, Users, Award } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const impactMetrics = [
  { label: 'Reach', value: 87, icon: Users },
  { label: 'Consistency', value: 92, icon: TrendingUp },
  { label: 'Quality', value: 78, icon: Award },
];

export default function ImpactScoreSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const bgRef = useRef<HTMLDivElement>(null);
  const leftContentRef = useRef<HTMLDivElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);
  const scoreRef = useRef<HTMLDivElement>(null);
  const [score, setScore] = useState(0);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const bg = bgRef.current;
    const leftContent = leftContentRef.current;
    const card = cardRef.current;
    const scoreEl = scoreRef.current;

    if (!section || !bg || !leftContent || !card || !scoreEl) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
          onUpdate: (self) => {
            // Update score based on scroll progress during settle phase
            if (self.progress >= 0.3 && self.progress <= 0.7) {
              const settleProgress = (self.progress - 0.3) / 0.4;
              setScore(Math.round(settleProgress * 847));
            }
          },
        },
      });

      // ENTRANCE (0%-30%)
      scrollTl.fromTo(
        bg,
        { scale: 1.08, opacity: 0.6 },
        { scale: 1, opacity: 1, ease: 'none' },
        0
      );

      scrollTl.fromTo(
        leftContent,
        { x: '-55vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0
      );

      scrollTl.fromTo(
        card,
        { x: '60vw', opacity: 0, scale: 0.97 },
        { x: 0, opacity: 1, scale: 1, ease: 'none' },
        0
      );

      // SETTLE (30%-70%): Score count up and bars fill
      const barFills = card.querySelectorAll('.impact-bar-fill');
      scrollTl.fromTo(
        barFills,
        { width: '0%' },
        { width: (_i, el) => (el as HTMLElement).dataset.width || '0%', ease: 'none' },
        0.3
      );

      // EXIT (70%-100%)
      scrollTl.fromTo(
        bg,
        { opacity: 1 },
        { opacity: 0.35, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(
        leftContent,
        { x: 0, opacity: 1 },
        { x: '-16vw', opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(
        card,
        { x: 0, opacity: 1, scale: 1 },
        { x: '20vw', opacity: 0, scale: 0.98, ease: 'power2.in' },
        0.7
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="section-pinned z-[70] flex items-center"
    >
      {/* Background Image */}
      <div
        ref={bgRef}
        className="absolute inset-0 z-0"
        style={{
          backgroundImage: 'url(/impact_laptop_closeup.jpg)',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      >
        <div className="vignette" />
      </div>

      {/* Content */}
      <div className="relative z-10 w-full px-6 lg:px-[6vw] flex flex-col lg:flex-row items-center justify-between gap-12">
        {/* Left Content */}
        <div ref={leftContentRef} className="flex-1 max-w-lg">
          {/* Headline */}
          <div className="mb-8">
            <h2 className="headline-lg text-devprint-text" style={{ fontSize: 'clamp(36px, 4.6vw, 72px)' }}>
              <span className="block">IMPACT</span>
              <span className="block text-devprint-accent">SCORE</span>
            </h2>
          </div>

          {/* Body */}
          <p className="text-devprint-text-secondary text-lg leading-relaxed mb-8">
            A single number derived from stars, forks, downloads, and community 
            engagement—normalized across platforms.
          </p>

          {/* CTA */}
          <Button className="btn-primary rounded-full">
            Check your score
          </Button>
        </div>

        {/* Right Score Card */}
        <div
          ref={cardRef}
          className="w-full lg:w-[34vw] lg:h-[64vh] card-glass p-6 lg:p-8 flex flex-col"
        >
          {/* Big Score */}
          <div ref={scoreRef} className="text-center mb-8">
            <div className="stat-number text-6xl lg:text-7xl mb-2">{score}</div>
            <p className="text-devprint-text-secondary text-sm uppercase tracking-wider">
              Impact Score
            </p>
          </div>

          {/* Sub Metrics */}
          <div className="space-y-5 flex-1">
            {impactMetrics.map((metric, i) => (
              <div key={i} className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <metric.icon className="w-4 h-4 text-devprint-accent" />
                    <span className="text-devprint-text text-sm font-medium">{metric.label}</span>
                  </div>
                  <span className="text-devprint-accent font-mono text-sm">{metric.value}</span>
                </div>
                <div className="progress-bar">
                  <div
                    className="impact-bar-fill progress-bar-fill"
                    data-width={`${metric.value}%`}
                    style={{ width: '0%' }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
