import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Copy, Check } from 'lucide-react';
import { useState } from 'react';

gsap.registerPlugin(ScrollTrigger);

// Generate mock heatmap data (52 weeks x 7 days)
const generateHeatmapData = () => {
  const data = [];
  for (let week = 0; week < 52; week++) {
    const weekData = [];
    for (let day = 0; day < 7; day++) {
      // Random activity level 0-4
      const level = Math.random() > 0.6 ? Math.floor(Math.random() * 4) + 1 : 0;
      weekData.push(level);
    }
    data.push(weekData);
  }
  return data;
};

const heatmapData = generateHeatmapData();
const monthLabels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

export default function HeatmapSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const leftContentRef = useRef<HTMLDivElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);
  const gridRef = useRef<HTMLDivElement>(null);
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText('<iframe src="devprint.dev/heatmap/johndoe" />');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const leftContent = leftContentRef.current;
    const card = cardRef.current;
    const grid = gridRef.current;

    if (!section || !leftContent || !card || !grid) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // ENTRANCE (0%-30%)
      scrollTl.fromTo(
        leftContent,
        { x: '-55vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0
      );

      scrollTl.fromTo(
        card,
        { x: '60vw', opacity: 0, scale: 0.98 },
        { x: 0, opacity: 1, scale: 1, ease: 'none' },
        0
      );

      // SETTLE (30%-70%): Grid cells animate in
      const cells = grid.querySelectorAll('.heatmap-cell');
      scrollTl.fromTo(
        cells,
        { opacity: 0.2, scale: 0.9 },
        { opacity: 1, scale: 1, stagger: 0.002, ease: 'none' },
        0.3
      );

      // EXIT (70%-100%)
      scrollTl.fromTo(
        leftContent,
        { x: 0, opacity: 1 },
        { x: '-16vw', opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(
        card,
        { x: 0, opacity: 1, scale: 1 },
        { x: '22vw', opacity: 0, scale: 0.98, ease: 'power2.in' },
        0.7
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="section-pinned z-[60] flex items-center"
      style={{ background: '#07070B' }}
    >
      <div className="w-full px-6 lg:px-[6vw] flex flex-col lg:flex-row items-center justify-between gap-12">
        {/* Left Content */}
        <div ref={leftContentRef} className="flex-1 max-w-lg">
          {/* Headline */}
          <div className="mb-8">
            <h2 className="headline-lg text-devprint-text" style={{ fontSize: 'clamp(36px, 4.6vw, 72px)' }}>
              <span className="block">YOUR CODING</span>
              <span className="block text-devprint-accent">RHYTHM</span>
            </h2>
          </div>

          {/* Body */}
          <p className="text-devprint-text-secondary text-lg leading-relaxed mb-8">
            A year of commits—rendered as a clean heatmap you can embed anywhere. 
            No config needed.
          </p>

          {/* Copy Link */}
          <button
            onClick={handleCopy}
            className="link-pill group hover:border-devprint-accent/50 transition-colors"
          >
            <span>Copy embed code</span>
            {copied ? (
              <Check className="w-4 h-4 text-devprint-accent" />
            ) : (
              <Copy className="w-4 h-4 opacity-50 group-hover:opacity-100 transition-opacity" />
            )}
          </button>
        </div>

        {/* Right Heatmap Card */}
        <div
          ref={cardRef}
          className="w-full lg:w-[36vw] lg:h-[64vh] card-glass p-6 lg:p-8 overflow-hidden"
        >
          {/* Month Labels */}
          <div className="flex justify-between mb-3 px-1">
            {monthLabels.map((month, i) => (
              <span key={i} className="text-xs text-devprint-text-secondary">
                {month}
              </span>
            ))}
          </div>

          {/* Heatmap Grid */}
          <div ref={gridRef} className="flex gap-[3px] overflow-x-auto pb-2">
            {heatmapData.map((week, weekIndex) => (
              <div key={weekIndex} className="flex flex-col gap-[3px]">
                {week.map((level, dayIndex) => (
                  <div
                    key={dayIndex}
                    className={`heatmap-cell w-[10px] h-[10px] rounded-sm level-${level}`}
                  />
                ))}
              </div>
            ))}
          </div>

          {/* Legend */}
          <div className="flex items-center justify-end gap-2 mt-4">
            <span className="text-xs text-devprint-text-secondary">Less</span>
            <div className="flex gap-1">
              <div className="w-[10px] h-[10px] rounded-sm bg-devprint-text/5" />
              <div className="w-[10px] h-[10px] rounded-sm bg-devprint-accent/20" />
              <div className="w-[10px] h-[10px] rounded-sm bg-devprint-accent/40" />
              <div className="w-[10px] h-[10px] rounded-sm bg-devprint-accent/60" />
              <div className="w-[10px] h-[10px] rounded-sm bg-devprint-accent/85" />
            </div>
            <span className="text-xs text-devprint-text-secondary">More</span>
          </div>
        </div>
      </div>
    </section>
  );
}
