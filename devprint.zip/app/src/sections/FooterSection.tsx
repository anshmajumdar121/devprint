import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Github, Twitter, Mail } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const footerLinks = {
  Product: ['Features', 'Pricing', 'Changelog', 'Roadmap'],
  Company: ['About', 'Blog', 'Careers', 'Press'],
  Resources: ['Docs', 'API', 'Community', 'Support'],
  Legal: ['Privacy', 'Terms', 'Security', 'Cookies'],
};

export default function FooterSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const content = contentRef.current;

    if (!section || !content) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(
        content,
        { y: 16, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.5,
          scrollTrigger: {
            trigger: content,
            start: 'top 90%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <footer
      ref={sectionRef}
      className="section-flowing z-[120] py-16 lg:py-20 border-t border-white/5"
      style={{ background: '#07070B' }}
    >
      <div ref={contentRef} className="px-6 lg:px-[6vw]">
        {/* Main Footer */}
        <div className="grid grid-cols-2 md:grid-cols-6 gap-8 lg:gap-12 mb-12">
          {/* Brand */}
          <div className="col-span-2">
            <a href="/" className="inline-block mb-4">
              <span className="font-display font-bold text-2xl text-devprint-text">
                DevPrint
              </span>
            </a>
            <p className="text-devprint-text-secondary text-sm mb-4 max-w-xs">
              Your code. Your story. One link.
            </p>
            <a
              href="mailto:hello@devprint.dev"
              className="inline-flex items-center gap-2 text-devprint-accent text-sm hover:underline"
            >
              <Mail className="w-4 h-4" />
              hello@devprint.dev
            </a>
          </div>

          {/* Links */}
          {Object.entries(footerLinks).map(([category, links]) => (
            <div key={category}>
              <h4 className="font-display font-semibold text-devprint-text mb-4">
                {category}
              </h4>
              <ul className="space-y-2">
                {links.map((link) => (
                  <li key={link}>
                    <a
                      href="#"
                      className="text-devprint-text-secondary text-sm hover:text-devprint-text transition-colors"
                    >
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom Bar */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 pt-8 border-t border-white/5">
          <p className="text-devprint-text-secondary text-sm">
            © {new Date().getFullYear()} DevPrint. All rights reserved.
          </p>
          <div className="flex items-center gap-4">
            <a
              href="#"
              className="w-10 h-10 rounded-full bg-devprint-surface flex items-center justify-center text-devprint-text-secondary hover:text-devprint-text hover:bg-devprint-accent/10 transition-colors"
            >
              <Github className="w-5 h-5" />
            </a>
            <a
              href="#"
              className="w-10 h-10 rounded-full bg-devprint-surface flex items-center justify-center text-devprint-text-secondary hover:text-devprint-text hover:bg-devprint-accent/10 transition-colors"
            >
              <Twitter className="w-5 h-5" />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
