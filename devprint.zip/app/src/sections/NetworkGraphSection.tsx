import { useRef, useLayoutEffect, useEffect, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Button } from '@/components/ui/button';
import { Share2, GitBranch, User } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface Node {
  id: number;
  x: number;
  y: number;
  type: string;
  r: number;
}

interface Edge {
  source: Node;
  target: Node;
}

// Generate random nodes
const generateNodes = (count: number): Node[] => {
  return Array.from({ length: count }, (_, i) => ({
    id: i,
    x: Math.random() * 280 + 20,
    y: Math.random() * 200 + 20,
    type: i < 3 ? 'developer' : i < 8 ? 'repo' : 'connection',
    r: i < 3 ? 6 : i < 8 ? 4 : 3,
  }));
};

// Generate edges between nodes
const generateEdges = (nodes: Node[]): Edge[] => {
  const edges: Edge[] = [];
  for (let i = 0; i < nodes.length; i++) {
    for (let j = i + 1; j < nodes.length; j++) {
      if (Math.random() > 0.7) {
        edges.push({ source: nodes[i], target: nodes[j] });
      }
    }
  }
  return edges;
};

const nodes = generateNodes(15);
const edges = generateEdges(nodes);

export default function NetworkGraphSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const leftContentRef = useRef<HTMLDivElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);
  const svgRef = useRef<SVGSVGElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const leftContent = leftContentRef.current;
    const card = cardRef.current;

    if (!section || !leftContent || !card) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
          onEnter: () => setIsVisible(true),
        },
      });

      // ENTRANCE (0%-30%)
      scrollTl.fromTo(
        leftContent,
        { x: '-55vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0
      );

      scrollTl.fromTo(
        card,
        { x: '60vw', opacity: 0, scale: 0.98 },
        { x: 0, opacity: 1, scale: 1, ease: 'none' },
        0
      );

      // SETTLE (30%-70%): Nodes and edges animate
      const svgNodes = svgRef.current?.querySelectorAll('.graph-node');
      const svgEdges = svgRef.current?.querySelectorAll('.graph-edge');

      if (svgNodes && svgEdges) {
        scrollTl.fromTo(
          svgNodes,
          { scale: 0.6, opacity: 0.4 },
          { scale: 1, opacity: 1, stagger: 0.01, ease: 'none' },
          0.3
        );

        scrollTl.fromTo(
          svgEdges,
          { strokeDashoffset: 100 },
          { strokeDashoffset: 0, ease: 'none' },
          0.35
        );
      }

      // EXIT (70%-100%)
      scrollTl.fromTo(
        leftContent,
        { x: 0, opacity: 1 },
        { x: '-16vw', opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(
        card,
        { x: 0, opacity: 1, scale: 1 },
        { x: '22vw', opacity: 0, scale: 0.98, ease: 'power2.in' },
        0.7
      );
    }, section);

    return () => ctx.revert();
  }, []);

  // Animate nodes continuously when visible
  useEffect(() => {
    if (!isVisible || !svgRef.current) return;

    const svgNodes = svgRef.current.querySelectorAll('.graph-node');
    const animations: gsap.core.Tween[] = [];

    svgNodes.forEach((node, index) => {
      const anim = gsap.to(node, {
        x: `+=${Math.random() * 10 - 5}`,
        y: `+=${Math.random() * 10 - 5}`,
        duration: 2 + Math.random() * 2,
        repeat: -1,
        yoyo: true,
        ease: 'sine.inOut',
        delay: index * 0.1,
      });
      animations.push(anim);
    });

    return () => {
      animations.forEach((anim) => anim.kill());
    };
  }, [isVisible]);

  return (
    <section
      ref={sectionRef}
      className="section-pinned z-[80] flex items-center"
      style={{ background: '#07070B' }}
    >
      <div className="w-full px-6 lg:px-[6vw] flex flex-col lg:flex-row items-center justify-between gap-12">
        {/* Left Content */}
        <div ref={leftContentRef} className="flex-1 max-w-lg">
          {/* Headline */}
          <div className="mb-8">
            <h2 className="headline-lg text-devprint-text" style={{ fontSize: 'clamp(36px, 4.6vw, 72px)' }}>
              <span className="block">DISCOVER</span>
              <span className="block text-devprint-accent">THE NETWORK</span>
            </h2>
          </div>

          {/* Body */}
          <p className="text-devprint-text-secondary text-lg leading-relaxed mb-8">
            Explore how developers connect through repos, stacks, and contributions—
            then find your next collaborator.
          </p>

          {/* CTA */}
          <Button className="btn-primary rounded-full">
            <Share2 className="w-4 h-4 mr-2" />
            Explore the graph
          </Button>
        </div>

        {/* Right Graph Card */}
        <div
          ref={cardRef}
          className="w-full lg:w-[36vw] lg:h-[64vh] card-glass p-6 lg:p-8"
        >
          {/* SVG Graph */}
          <svg
            ref={svgRef}
            viewBox="0 0 320 240"
            className="w-full h-[200px] lg:h-[280px]"
          >
            {/* Edges */}
            {edges.map((edge, edgeIndex) => (
              <line
                key={edgeIndex}
                className="graph-edge"
                x1={edge.source.x}
                y1={edge.source.y}
                x2={edge.target.x}
                y2={edge.target.y}
                stroke="rgba(244, 246, 240, 0.15)"
                strokeWidth="1"
                strokeDasharray="100"
                strokeDashoffset="100"
              />
            ))}

            {/* Nodes */}
            {nodes.map((node, nodeIndex) => (
              <circle
                key={nodeIndex}
                className="graph-node"
                cx={node.x}
                cy={node.y}
                r={node.r}
                fill={node.type === 'developer' ? '#B6FF2E' : node.type === 'repo' ? '#F4F6F0' : '#A7A7B6'}
                opacity={node.type === 'connection' ? 0.5 : 1}
              />
            ))}
          </svg>

          {/* Legend */}
          <div className="flex items-center justify-center gap-6 mt-4">
            <div className="flex items-center gap-2">
              <User className="w-4 h-4 text-devprint-accent" />
              <span className="text-xs text-devprint-text-secondary">Developers</span>
            </div>
            <div className="flex items-center gap-2">
              <GitBranch className="w-4 h-4 text-devprint-text" />
              <span className="text-xs text-devprint-text-secondary">Repos</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-devprint-text-secondary" />
              <span className="text-xs text-devprint-text-secondary">Connections</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
