import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Link2, Menu, X } from 'lucide-react';

export default function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 100);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Product', href: '#product' },
    { label: 'Features', href: '#features' },
    { label: 'Pricing', href: '#pricing' },
    { label: 'Docs', href: '#docs' },
  ];

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-devprint-bg/80 backdrop-blur-xl border-b border-white/5'
          : 'bg-transparent'
      }`}
    >
      <div className="flex items-center justify-between px-6 lg:px-12 h-16">
        {/* Logo */}
        <a href="/" className="flex items-center gap-2">
          <span className="font-display font-bold text-xl text-devprint-text tracking-tight">
            DevPrint
          </span>
        </a>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <a
              key={link.label}
              href={link.href}
              className="text-sm text-devprint-text-secondary hover:text-devprint-text transition-colors"
            >
              {link.label}
            </a>
          ))}
        </div>

        {/* CTA */}
        <div className="hidden md:flex items-center gap-4">
          <Button
            variant="outline"
            className="rounded-full border-devprint-accent/50 text-devprint-accent hover:bg-devprint-accent/10 hover:text-devprint-accent"
          >
            <Link2 className="w-4 h-4 mr-2" />
            Get your link
          </Button>
        </div>

        {/* Mobile Menu Button */}
        <button
          className="md:hidden p-2 text-devprint-text"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-devprint-bg/95 backdrop-blur-xl border-b border-white/5">
          <div className="flex flex-col p-6 gap-4">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="text-lg text-devprint-text-secondary hover:text-devprint-text transition-colors"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                {link.label}
              </a>
            ))}
            <Button
              variant="outline"
              className="rounded-full border-devprint-accent/50 text-devprint-accent hover:bg-devprint-accent/10 mt-4"
            >
              <Link2 className="w-4 h-4 mr-2" />
              Get your link
            </Button>
          </div>
        </div>
      )}
    </nav>
  );
}
