import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Github, Link2, Share } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const steps = [
  {
    number: '01',
    title: 'Connect GitHub',
    description: 'We index your public repos, stars, and contribution history.',
    icon: Github,
  },
  {
    number: '02',
    title: 'Add your links',
    description: 'Optional: dev.to, Hashnode, ProductHunt, LinkedIn.',
    icon: Link2,
  },
  {
    number: '03',
    title: 'Share your card',
    description: 'One link. Embed anywhere. Update automatically.',
    icon: Share,
  },
];

export default function HowItWorksSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const headline = headlineRef.current;
    const cards = cardsRef.current;

    if (!section || !headline || !cards) return;

    const ctx = gsap.context(() => {
      // Headline animation
      gsap.fromTo(
        headline,
        { y: 30, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.6,
          scrollTrigger: {
            trigger: headline,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Cards animation with stagger
      const cardItems = cards.querySelectorAll('.step-card');
      gsap.fromTo(
        cardItems,
        { y: 40, opacity: 0, scale: 0.98 },
        {
          y: 0,
          opacity: 1,
          scale: 1,
          stagger: 0.12,
          duration: 0.6,
          scrollTrigger: {
            trigger: cards,
            start: 'top 75%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="product"
      className="section-flowing z-[90] py-20 lg:py-32"
      style={{ background: '#0F0F14' }}
    >
      <div className="px-6 lg:px-[6vw]">
        {/* Headline */}
        <div ref={headlineRef} className="mb-16 lg:mb-20">
          <h2 className="headline-lg text-devprint-text" style={{ fontSize: 'clamp(36px, 4.6vw, 72px)' }}>
            <span className="block">SETUP IN</span>
            <span className="block text-devprint-accent">60 SECONDS</span>
          </h2>
        </div>

        {/* Steps */}
        <div
          ref={cardsRef}
          className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8"
        >
          {steps.map((step, i) => (
            <div
              key={i}
              className="step-card card-glass p-6 lg:p-8 hover:border-devprint-accent/30 transition-colors"
            >
              {/* Step Number */}
              <div className="text-devprint-accent font-mono text-sm mb-4">
                {step.number}
              </div>

              {/* Icon */}
              <div className="w-12 h-12 rounded-xl bg-devprint-accent/10 flex items-center justify-center mb-6">
                <step.icon className="w-6 h-6 text-devprint-accent" />
              </div>

              {/* Content */}
              <h3 className="font-display font-bold text-xl text-devprint-text mb-3">
                {step.title}
              </h3>
              <p className="text-devprint-text-secondary leading-relaxed">
                {step.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
