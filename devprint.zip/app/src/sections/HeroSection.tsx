import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Button } from '@/components/ui/button';
import { ArrowRight, ExternalLink } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export default function HeroSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const subheadRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);
  const bgRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const headline = headlineRef.current;
    const subhead = subheadRef.current;
    const cta = ctaRef.current;
    const bg = bgRef.current;

    if (!section || !headline || !subhead || !cta || !bg) return;

    const ctx = gsap.context(() => {
      // Auto-play entrance animation
      const tl = gsap.timeline({ defaults: { ease: 'power2.out' } });

      tl.fromTo(bg, { opacity: 0 }, { opacity: 1, duration: 0.6 });

      const lines = headline.querySelectorAll('.headline-line');
      tl.fromTo(
        lines,
        { y: 24, opacity: 0 },
        { y: 0, opacity: 1, stagger: 0.08, duration: 0.6 },
        '-=0.3'
      );

      tl.fromTo(
        subhead,
        { y: 14, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.5 },
        '-=0.3'
      );

      tl.fromTo(
        cta.children,
        { y: 14, opacity: 0 },
        { y: 0, opacity: 1, stagger: 0.06, duration: 0.5 },
        '-=0.3'
      );

      // Scroll-driven exit animation
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
          onLeaveBack: () => {
            // Reset to visible state when scrolling back
            gsap.set([headline, subhead, cta], { opacity: 1, y: 0, x: 0 });
            gsap.set(bg, { opacity: 1, scale: 1 });
          },
        },
      });

      // ENTRANCE (0%-30%): Hold visible state
      scrollTl.fromTo(
        headline,
        { opacity: 1, y: 0 },
        { opacity: 1, y: 0, ease: 'none' },
        0
      );

      scrollTl.fromTo(
        bg,
        { scale: 1 },
        { scale: 1.03, ease: 'none' },
        0
      );

      // SETTLE (30%-70%): Hold

      // EXIT (70%-100%): Fade out
      scrollTl.fromTo(
        headline,
        { y: 0, opacity: 1 },
        { y: '-22vh', opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(
        subhead,
        { y: 0, opacity: 1 },
        { y: '-18vh', opacity: 0, ease: 'power2.in' },
        0.72
      );

      scrollTl.fromTo(
        cta,
        { y: 0, opacity: 1 },
        { y: '-16vh', opacity: 0, ease: 'power2.in' },
        0.74
      );

      scrollTl.fromTo(
        bg,
        { scale: 1.03, opacity: 1 },
        { scale: 1.08, opacity: 0.35, ease: 'power2.in' },
        0.7
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="section-pinned z-10 flex items-center"
      style={{ background: '#07070B' }}
    >
      {/* Background Image */}
      <div
        ref={bgRef}
        className="absolute inset-0 z-0"
        style={{
          backgroundImage: 'url(/hero_coder_desk.jpg)',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      >
        <div className="vignette" />
      </div>

      {/* Content */}
      <div className="relative z-10 w-full px-6 lg:px-[6vw]">
        {/* Headline */}
        <div ref={headlineRef} className="mb-8">
          <h1 className="headline-xl text-devprint-text" style={{ fontSize: 'clamp(44px, 6vw, 96px)' }}>
            <span className="headline-line block">YOUR CODE</span>
            <span className="headline-line block">YOUR STORY</span>
            <span className="headline-line block text-devprint-accent">ONE LINK</span>
          </h1>
        </div>

        {/* Subheadline */}
        <p
          ref={subheadRef}
          className="text-devprint-text-secondary text-lg lg:text-xl max-w-md mb-10"
        >
          DevPrint turns your commits, repos, and writing into a living identity card.
        </p>

        {/* CTAs */}
        <div ref={ctaRef} className="flex flex-wrap gap-4">
          <Button className="btn-primary rounded-full px-8 py-6 text-base font-medium">
            Create your DevPrint
            <ArrowRight className="w-5 h-5 ml-2" />
          </Button>
          <Button className="btn-ghost rounded-full px-8 py-6 text-base">
            <ExternalLink className="w-5 h-5 mr-2" />
            View example profile
          </Button>
        </div>

        {/* Micro hint */}
        <p className="absolute bottom-8 left-6 lg:left-[6vw] text-sm text-devprint-text-secondary/60">
          Scroll to explore
        </p>
      </div>
    </section>
  );
}
