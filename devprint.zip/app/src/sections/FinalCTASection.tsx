import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Button } from '@/components/ui/button';
import { ArrowRight, ExternalLink } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export default function FinalCTASection() {
  const sectionRef = useRef<HTMLElement>(null);
  const bgRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const bg = bgRef.current;
    const headline = headlineRef.current;
    const content = contentRef.current;

    if (!section || !bg || !headline || !content) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // ENTRANCE (0%-30%)
      scrollTl.fromTo(
        bg,
        { scale: 1.08, opacity: 0.6 },
        { scale: 1, opacity: 1, ease: 'none' },
        0
      );

      scrollTl.fromTo(
        headline,
        { y: '40vh', opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0
      );

      scrollTl.fromTo(
        content.children,
        { y: '18vh', opacity: 0 },
        { y: 0, opacity: 1, stagger: 0.02, ease: 'none' },
        0.08
      );

      // SETTLE (30%-70%): Hold

      // EXIT (70%-100%)
      scrollTl.fromTo(
        bg,
        { opacity: 1 },
        { opacity: 0.35, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(
        headline,
        { y: 0, opacity: 1 },
        { y: '-12vh', opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(
        content.children,
        { opacity: 1 },
        { opacity: 0, stagger: 0.01, ease: 'power2.in' },
        0.72
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="section-pinned z-[110] flex items-center justify-center"
    >
      {/* Background Image */}
      <div
        ref={bgRef}
        className="absolute inset-0 z-0"
        style={{
          backgroundImage: 'url(/final_coder_desk.jpg)',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      >
        <div className="vignette" />
      </div>

      {/* Content */}
      <div className="relative z-10 w-full px-6 lg:px-[6vw] text-center">
        {/* Headline */}
        <div ref={headlineRef} className="mb-8">
          <h2 className="headline-lg text-devprint-text" style={{ fontSize: 'clamp(36px, 5vw, 80px)' }}>
            <span className="block">READY TO PRINT</span>
            <span className="block text-devprint-accent">YOUR IDENTITY?</span>
          </h2>
        </div>

        {/* Content */}
        <div ref={contentRef} className="flex flex-col items-center gap-6">
          <p className="text-devprint-text-secondary text-lg max-w-lg">
            Join 120,000+ developers who use DevPrint as their home on the internet.
          </p>

          <div className="flex flex-wrap justify-center gap-4">
            <Button className="btn-primary rounded-full px-8 py-6 text-base">
              Create your DevPrint
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
            <Button className="btn-ghost rounded-full px-8 py-6 text-base">
              <ExternalLink className="w-5 h-5 mr-2" />
              View example profile
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
