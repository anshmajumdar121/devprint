import { useRef, useLayoutEffect, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Check, Zap, Users, Crown } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const plans = [
  {
    name: 'Free',
    icon: Zap,
    monthlyPrice: 0,
    yearlyPrice: 0,
    description: 'Public profile + basic stats',
    features: [
      'GitHub public repos sync',
      'Basic profile card',
      'Public heatmap',
      'Shareable link',
    ],
    cta: 'Get started',
    highlighted: false,
  },
  {
    name: 'Pro',
    icon: Crown,
    monthlyPrice: 9,
    yearlyPrice: 90,
    description: 'Private insights + resume export + AI chat',
    features: [
      'Everything in Free',
      'Private repo analysis',
      'Resume PDF export',
      'AI chat (20 msgs/day)',
      'Advanced analytics',
      'Priority support',
    ],
    cta: 'Upgrade to Pro',
    highlighted: true,
  },
  {
    name: 'Team',
    icon: Users,
    monthlyPrice: 29,
    yearlyPrice: 290,
    description: '5 seats + hiring view + analytics',
    features: [
      'Everything in Pro',
      '5 team seats',
      'Hiring manager view',
      'Team analytics dashboard',
      'SSO integration',
      'Dedicated support',
    ],
    cta: 'Contact sales',
    highlighted: false,
  },
];

export default function PricingSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const toggleRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);
  const [isYearly, setIsYearly] = useState(false);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const headline = headlineRef.current;
    const toggle = toggleRef.current;
    const cards = cardsRef.current;

    if (!section || !headline || !toggle || !cards) return;

    const ctx = gsap.context(() => {
      // Headline animation
      gsap.fromTo(
        headline,
        { y: 30, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.6,
          scrollTrigger: {
            trigger: headline,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Toggle animation
      gsap.fromTo(
        toggle,
        { y: 20, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.5,
          delay: 0.1,
          scrollTrigger: {
            trigger: toggle,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Cards animation with stagger
      const cardItems = cards.querySelectorAll('.pricing-card');
      gsap.fromTo(
        cardItems,
        { y: 40, opacity: 0, scale: 0.98 },
        {
          y: 0,
          opacity: 1,
          scale: 1,
          stagger: 0.12,
          duration: 0.6,
          scrollTrigger: {
            trigger: cards,
            start: 'top 75%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="pricing"
      className="section-flowing z-[100] py-20 lg:py-32"
      style={{ background: '#07070B' }}
    >
      <div className="px-6 lg:px-[6vw]">
        {/* Headline */}
        <div ref={headlineRef} className="mb-8">
          <h2 className="headline-lg text-devprint-text" style={{ fontSize: 'clamp(36px, 4.6vw, 72px)' }}>
            <span className="block">PRICING</span>
            <span className="block text-devprint-accent">THAT MAKES SENSE</span>
          </h2>
        </div>

        {/* Toggle */}
        <div ref={toggleRef} className="flex items-center justify-center gap-4 mb-16">
          <span className={`text-sm ${!isYearly ? 'text-devprint-text' : 'text-devprint-text-secondary'}`}>
            Monthly
          </span>
          <Switch
            checked={isYearly}
            onCheckedChange={setIsYearly}
            className="data-[state=checked]:bg-devprint-accent"
          />
          <span className={`text-sm ${isYearly ? 'text-devprint-text' : 'text-devprint-text-secondary'}`}>
            Yearly
          </span>
          {isYearly && (
            <span className="text-xs text-devprint-accent bg-devprint-accent/10 px-2 py-1 rounded-full">
              Save 17%
            </span>
          )}
        </div>

        {/* Pricing Cards */}
        <div
          ref={cardsRef}
          className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8"
        >
          {plans.map((plan, i) => (
            <div
              key={i}
              className={`pricing-card card-glass p-6 lg:p-8 flex flex-col ${
                plan.highlighted
                  ? 'border-devprint-accent/50 shadow-glow'
                  : 'hover:border-devprint-accent/20'
              } transition-all`}
            >
              {/* Header */}
              <div className="flex items-center gap-3 mb-4">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                  plan.highlighted ? 'bg-devprint-accent/20' : 'bg-devprint-surface'
                }`}>
                  <plan.icon className={`w-5 h-5 ${plan.highlighted ? 'text-devprint-accent' : 'text-devprint-text'}`} />
                </div>
                <div>
                  <h3 className="font-display font-bold text-lg text-devprint-text">
                    {plan.name}
                  </h3>
                </div>
              </div>

              {/* Price */}
              <div className="mb-4">
                <span className="text-4xl font-display font-bold text-devprint-text">
                  ${isYearly ? plan.yearlyPrice : plan.monthlyPrice}
                </span>
                <span className="text-devprint-text-secondary text-sm">
                  /{isYearly ? 'year' : 'mo'}
                </span>
              </div>

              {/* Description */}
              <p className="text-devprint-text-secondary text-sm mb-6">
                {plan.description}
              </p>

              {/* Features */}
              <ul className="space-y-3 mb-8 flex-1">
                {plan.features.map((feature, fi) => (
                  <li key={fi} className="flex items-start gap-3">
                    <Check className="w-4 h-4 text-devprint-accent mt-0.5 flex-shrink-0" />
                    <span className="text-devprint-text text-sm">{feature}</span>
                  </li>
                ))}
              </ul>

              {/* CTA */}
              <Button
                className={`w-full rounded-full py-5 ${
                  plan.highlighted
                    ? 'btn-primary'
                    : 'btn-ghost'
                }`}
              >
                {plan.cta}
              </Button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
