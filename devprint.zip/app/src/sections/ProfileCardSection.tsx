import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Button } from '@/components/ui/button';
import { Check, Star, GitFork, BookOpen, ExternalLink } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

gsap.registerPlugin(ScrollTrigger);

export default function ProfileCardSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const leftContentRef = useRef<HTMLDivElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const leftContent = leftContentRef.current;
    const card = cardRef.current;

    if (!section || !leftContent || !card) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // ENTRANCE (0%-30%)
      scrollTl.fromTo(
        leftContent,
        { x: '-55vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0
      );

      scrollTl.fromTo(
        card,
        { x: '60vw', opacity: 0, scale: 0.98, rotateZ: 1 },
        { x: 0, opacity: 1, scale: 1, rotateZ: 0, ease: 'none' },
        0
      );

      // SETTLE (30%-70%): Card floating animation handled by CSS

      // EXIT (70%-100%)
      scrollTl.fromTo(
        leftContent,
        { x: 0, opacity: 1 },
        { x: '-18vw', opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(
        card,
        { x: 0, opacity: 1, scale: 1 },
        { x: '22vw', opacity: 0, scale: 0.98, ease: 'power2.in' },
        0.7
      );
    }, section);

    return () => ctx.revert();
  }, []);

  const features = [
    'Auto-sync with GitHub & npm',
    'Clean, fast, responsive',
    'Share anywhere',
  ];

  return (
    <section
      ref={sectionRef}
      className="section-pinned z-30 flex items-center"
      style={{ background: '#07070B' }}
    >
      <div className="w-full px-6 lg:px-[6vw] flex flex-col lg:flex-row items-center justify-between gap-12">
        {/* Left Content */}
        <div ref={leftContentRef} className="flex-1 max-w-lg">
          {/* Headline */}
          <div className="mb-8">
            <h2 className="headline-lg text-devprint-text" style={{ fontSize: 'clamp(36px, 4.6vw, 72px)' }}>
              <span className="block">A LIVE CARD</span>
              <span className="block text-devprint-accent">FOR YOUR WORK</span>
            </h2>
          </div>

          {/* Body */}
          <p className="text-devprint-text-secondary text-lg leading-relaxed mb-8">
            Stats, repos, writing, and impact—automatically updated, beautifully presented.
          </p>

          {/* Features */}
          <ul className="space-y-3 mb-8">
            {features.map((feature, i) => (
              <li key={i} className="flex items-center gap-3 text-devprint-text">
                <div className="w-5 h-5 rounded-full bg-devprint-accent/20 flex items-center justify-center">
                  <Check className="w-3 h-3 text-devprint-accent" />
                </div>
                <span>{feature}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Right Profile Card */}
        <div
          ref={cardRef}
          className="w-full lg:w-[36vw] lg:h-[68vh] card-glass p-6 lg:p-8 animate-float relative"
        >
          {/* Card Header */}
          <div className="flex items-start gap-4 mb-6">
            <Avatar className="w-16 h-16 lg:w-[72px] lg:h-[72px] border-2 border-devprint-accent/30">
              <AvatarImage src="/portrait_identity.jpg" />
              <AvatarFallback className="bg-devprint-surface text-devprint-text">JD</AvatarFallback>
            </Avatar>
            <div>
              <h3 className="font-display font-bold text-xl text-devprint-text">John Doe</h3>
              <p className="text-devprint-text-secondary text-sm">@johndoe</p>
            </div>
          </div>

          {/* Bio */}
          <p className="text-devprint-text-secondary text-sm leading-relaxed mb-6">
            Full-stack developer building tools for developers. Open source enthusiast. 
            Writing about React, Node.js, and system design.
          </p>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-3 mb-6">
            <div className="bg-devprint-surface rounded-xl p-3 text-center">
              <div className="flex items-center justify-center gap-1 text-devprint-accent mb-1">
                <Star className="w-4 h-4" />
                <span className="font-mono font-bold">2.4k</span>
              </div>
              <p className="text-xs text-devprint-text-secondary">Stars</p>
            </div>
            <div className="bg-devprint-surface rounded-xl p-3 text-center">
              <div className="flex items-center justify-center gap-1 text-devprint-accent mb-1">
                <GitFork className="w-4 h-4" />
                <span className="font-mono font-bold">847</span>
              </div>
              <p className="text-xs text-devprint-text-secondary">Forks</p>
            </div>
            <div className="bg-devprint-surface rounded-xl p-3 text-center">
              <div className="flex items-center justify-center gap-1 text-devprint-accent mb-1">
                <BookOpen className="w-4 h-4" />
                <span className="font-mono font-bold">42</span>
              </div>
              <p className="text-xs text-devprint-text-secondary">Articles</p>
            </div>
          </div>

          {/* CTA */}
          <Button className="w-full btn-primary rounded-xl py-5">
            View full profile
            <ExternalLink className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </div>
    </section>
  );
}
