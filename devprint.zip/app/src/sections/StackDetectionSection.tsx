import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Button } from '@/components/ui/button';
import { ArrowRight, Code2, Layers, Zap, Database } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const techStack = [
  { name: 'TypeScript', percentage: 92, icon: Code2 },
  { name: 'React', percentage: 88, icon: Layers },
  { name: 'Node.js', percentage: 76, icon: Zap },
  { name: 'PostgreSQL', percentage: 64, icon: Database },
];

export default function StackDetectionSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const bgRef = useRef<HTMLDivElement>(null);
  const leftContentRef = useRef<HTMLDivElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);
  const barsRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const bg = bgRef.current;
    const leftContent = leftContentRef.current;
    const card = cardRef.current;
    const bars = barsRef.current;

    if (!section || !bg || !leftContent || !card || !bars) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // ENTRANCE (0%-30%)
      scrollTl.fromTo(
        bg,
        { scale: 1.08, opacity: 0.6 },
        { scale: 1, opacity: 1, ease: 'none' },
        0
      );

      scrollTl.fromTo(
        leftContent,
        { x: '-55vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0
      );

      scrollTl.fromTo(
        card,
        { x: '60vw', opacity: 0, scale: 0.97 },
        { x: 0, opacity: 1, scale: 1, ease: 'none' },
        0
      );

      // SETTLE (30%-70%): Tech bars fill animation
      const barFills = bars.querySelectorAll('.tech-bar-fill');
      scrollTl.fromTo(
        barFills,
        { width: '0%' },
        { width: (_i, el) => (el as HTMLElement).dataset.width || '0%', ease: 'none' },
        0.3
      );

      // EXIT (70%-100%)
      scrollTl.fromTo(
        bg,
        { scale: 1, opacity: 1 },
        { scale: 1.06, opacity: 0.35, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(
        leftContent,
        { x: 0, opacity: 1 },
        { x: '-16vw', opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(
        card,
        { x: 0, opacity: 1, scale: 1 },
        { x: '20vw', opacity: 0, scale: 0.98, ease: 'power2.in' },
        0.7
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="section-pinned z-50 flex items-center"
    >
      {/* Background Image */}
      <div
        ref={bgRef}
        className="absolute inset-0 z-0"
        style={{
          backgroundImage: 'url(/stack_headphones.jpg)',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      >
        <div className="vignette" />
      </div>

      {/* Content */}
      <div className="relative z-10 w-full px-6 lg:px-[6vw] flex flex-col lg:flex-row items-center justify-between gap-12">
        {/* Left Content */}
        <div ref={leftContentRef} className="flex-1 max-w-lg">
          {/* Headline */}
          <div className="mb-8">
            <h2 className="headline-lg text-devprint-text" style={{ fontSize: 'clamp(36px, 4.6vw, 72px)' }}>
              <span className="block">STACKS</span>
              <span className="block text-devprint-accent">DETECTED</span>
            </h2>
          </div>

          {/* Body */}
          <p className="text-devprint-text-secondary text-lg leading-relaxed mb-8">
            DevPrint reads your repos and packages to surface the technologies you actually 
            use—ranked by real-world usage.
          </p>

          {/* CTA */}
          <Button className="btn-ghost rounded-full">
            See how it works
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>

        {/* Right Stack Card */}
        <div
          ref={cardRef}
          className="w-full lg:w-[34vw] lg:h-[64vh] card-glass p-6 lg:p-8"
        >
          <h3 className="font-display font-bold text-xl text-devprint-text mb-6">
            Top Technologies
          </h3>

          {/* Tech List */}
          <div ref={barsRef} className="space-y-5">
            {techStack.map((tech, i) => (
              <div key={i} className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <tech.icon className="w-4 h-4 text-devprint-accent" />
                    <span className="text-devprint-text text-sm font-medium">{tech.name}</span>
                  </div>
                  <span className="text-devprint-accent font-mono text-sm">{tech.percentage}%</span>
                </div>
                <div className="progress-bar">
                  <div
                    className="tech-bar-fill progress-bar-fill"
                    data-width={`${tech.percentage}%`}
                    style={{ width: '0%' }}
                  />
                </div>
              </div>
            ))}
          </div>

          {/* Footer */}
          <p className="text-devprint-text-secondary text-xs mt-8">
            Updated from your latest commits
          </p>
        </div>
      </div>
    </section>
  );
}
